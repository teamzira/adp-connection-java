/*
	---------------------------------------------------------------------------
	Copyright © 2015-2016 ADP, LLC.   
	
	Licensed under the Apache License, Version 2.0 (the “License”); 
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at
	
	http://www.apache.org/licenses/LICENSE-2.0
	
	Unless required by applicable law or agreed to in writing, software 
	distributed under the License is distributed on an “AS IS” BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
	implied.  See the License for the specific language governing 
	permissions and limitations under the License.
	---------------------------------------------------------------------------
*/
package com.adp.marketplace.demo.client.auth.clientcred;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.adp.marketplace.connection.configuration.ClientCredentialsConfiguration;
import com.adp.marketplace.connection.configuration.ConnectionConfiguration;
import com.adp.marketplace.connection.core.ADPAPIConnectionFactory;
import com.adp.marketplace.connection.core.ClientCredentialsConnection;
import com.adp.marketplace.demo.client.auth.clientcred.pojo.Token;
import com.adp.marketplace.demo.client.auth.clientcred.utils.ClientUtils;
import com.adp.marketplace.product.userinfo.core.UserInfoHelper;


/**
 * <p>
 * ADPDemoClientCredentials is sample stand alone application
 * for verifying Connection is established with Authentication 
 * Server and an Access Token is issued. </p> 
 * 
 * @author tallaprs
 *
 */
public class ADPDemoClientCredentials {

	
	/**
	 * This method outlines the steps involved in client credentials authentication
	 * using ADPAPIConnection library 
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		//client credentials authentication 
		
		//initializes the client specific configurations
		ClientCredentialsConfiguration connectionConfiguration = buildClientConfig();
		
		//call to establish a connection with ADP
		ClientCredentialsConnection clientCredentialsConnection = 
											getADPAPIConnection(connectionConfiguration);
				
		//call to retrieve access token 
		Token token = getADPAuthorization(connectionConfiguration, clientCredentialsConnection);
		
		//verify - invoke userInfo api
		String userInfo = getUserInfo(clientCredentialsConnection);
		
	}

	/**
	 * this method creates and initializes the client credentials configuration 
	 * object with mapping the required properties
	 * 
	 * @return ClientCredentialsConfiguration
	 */
	private static ClientCredentialsConfiguration buildClientConfig() {
		
		//create an instance of ClientCredentialsConfiguration
		ClientCredentialsConfiguration connectionConfiguration = new ClientCredentialsConfiguration();
		
		try {
			
			Properties properties = ClientUtils.getInstance().getConfigProperties();
			ClientUtils.getInstance().mapPropertiesToClientCredentialsConfiguration(properties, connectionConfiguration);
			
		} catch (Exception e) {
			System.out.println(" Exception " + e.getMessage());
		}
		
		return connectionConfiguration; 
	}
	
	/**
	 * this method will return a Connection instance based on the connection configuration
	 * 
	 * @param connectionConfiguration
	 * @return ClientCredentialsConnection
	 */
	private static ClientCredentialsConnection getADPAPIConnection(ConnectionConfiguration 
		connectionConfiguration) {
		
		ClientCredentialsConnection clientCredentialsConnection = null;
		
		try {
			
			if ( connectionConfiguration != null) {
				
				clientCredentialsConnection = (ClientCredentialsConnection) 
						ADPAPIConnectionFactory.getInstance().createConnection(connectionConfiguration);

			} else {
				throw new IllegalArgumentException("ClientCredentialsConfiguration must not be null! ");
			}
			
		} catch (Exception e) {
			System.out.println(" Exception " + e.getMessage());
		}

		return clientCredentialsConnection;
	}
	
	/**
	 * Returns access token or an error response
	 * 
	 * @param clientCredentialsConnection
	 * @return Token
	 */
	private static Token getADPAuthorization(ConnectionConfiguration connectionConfiguration, 
			ClientCredentialsConnection clientCredentialsConnection) {
		
		Token token = null;
		
	    try {	
	    	
	    	if ( clientCredentialsConnection != null ) {
	    		throw new Exception("Client Credentials Connection is null!");
	    	}
	    	
	    	if ( connectionConfiguration == null ) {
				throw new Exception("ConnectionConfiguration Configuration is required!");
			}
	 
	    	// set connection configuration object after populating configuration with properties 
	    	clientCredentialsConnection.setConnectionConfiguration(connectionConfiguration);
	    	
	    	// invoke connect to acquire Access Token
	    	clientCredentialsConnection.connect();
	    	
	    	if ( clientCredentialsConnection != null ) {
				
				if ( clientCredentialsConnection.getToken() != null ) {
				
					boolean isAlive = clientCredentialsConnection.isConnectionIndicator();
					long expiration = clientCredentialsConnection.getToken().getExpires_in();	
				
					com.adp.marketplace.connection.vo.Token tokenResponse = clientCredentialsConnection.getToken();
				
					System.out.println( "\n-------Client Credentials Sample App Received below response -----------");				
					System.out.println( "ClientCredentialsConnection: Access Token : " + tokenResponse.toString());
					System.out.println( "ClientCredentialsConnection: Expiration:" +  expiration );
					System.out.println( "ClientCredentialsConnection: Connection is Alive:" +  isAlive );
					System.out.println( "--------------------------------------------------------------------------");
				
				} else if ( StringUtils.isNotBlank(clientCredentialsConnection.getErrorResponse() ) ) {
					System.out.println(" Error on Requesting Token - Message: " + clientCredentialsConnection.getErrorResponse());
				}
			}
			
	    } catch (Exception e) {
	    	System.out.println("getADPAuthorization Exception " + e);
		}
	    
		return token;
	}
	
	/**
	 * this method should not return any valid user information as the grant 
	 * type is 'client_credentials',.
	 * 
	 * @param connectionConfiguration
	 */
	private static String getUserInfo(ClientCredentialsConnection clientCredentialsConnection) {
		
		String response = null;
		
		try {
			
			if ( clientCredentialsConnection == null ) {
				throw new Exception("ConnectionConfiguration Configuration is required!");
			}
				
			UserInfoHelper userInfoHelper = new UserInfoHelper(clientCredentialsConnection);
			
			response = userInfoHelper.getUserInfo();
				
			if ( response != null ) {
				System.out.println( "\nClient App User Info: " + response);
			}
			
		} catch (Exception e) {
			System.out.println("\nUserInfo API is Not Implemented for GrantType - ClientCredentials" );
		}
		
		return response;
	}
	
}
