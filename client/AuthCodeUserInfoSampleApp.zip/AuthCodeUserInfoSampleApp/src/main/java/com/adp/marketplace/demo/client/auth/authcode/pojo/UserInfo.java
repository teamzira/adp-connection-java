/*
	---------------------------------------------------------------------------
	Copyright © 2015-2016 ADP, LLC.   
	
	Licensed under the Apache License, Version 2.0 (the “License”); 
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at
	
	http://www.apache.org/licenses/LICENSE-2.0
	
	Unless required by applicable law or agreed to in writing, software 
	distributed under the License is distributed on an “AS IS” BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
	implied.  See the License for the specific language governing 
	permissions and limitations under the License.
	---------------------------------------------------------------------------
*/
package com.adp.marketplace.demo.client.auth.authcode.pojo;

import java.io.Serializable;

/**
 * UserInfo is a simple value object class
 * 
 * @author tallaprs
 *
 */
public class UserInfo implements Serializable {

	private String sub;
	private String name;
	private String email;
	private String picture;
	private String familyName;
	private String givenName;
	private String associateOID;
	private String organizationOID;
	
	/**
	 * constructor
	 */
	public UserInfo() {}

	/**
	 * @return the sub
	 */
	public String getSub() {
		return sub;
	}

	/**
	 * @param sub the sub to set
	 */
	public void setSub(String sub) {
		this.sub = sub;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the picture
	 */
	public String getPicture() {
		return picture;
	}

	/**
	 * @param picture the picture to set
	 */
	public void setPicture(String picture) {
		this.picture = picture;
	}

	/**
	 * @return the familyName
	 */
	public String getFamilyName() {
		return familyName;
	}

	/**
	 * @param familyName the familyName to set
	 */
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	/**
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * @param givenName the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * @return the associateOID
	 */
	public String getAssociateOID() {
		return associateOID;
	}

	/**
	 * @param associateOID the associateOID to set
	 */
	public void setAssociateOID(String associateOID) {
		this.associateOID = associateOID;
	}

	/**
	 * @return the organizationOID
	 */
	public String getOrganizationOID() {
		return organizationOID;
	}

	/**
	 * @param organizationOID the organizationOID to set
	 */
	public void setOrganizationOID(String organizationOID) {
		this.organizationOID = organizationOID;
	}

}
