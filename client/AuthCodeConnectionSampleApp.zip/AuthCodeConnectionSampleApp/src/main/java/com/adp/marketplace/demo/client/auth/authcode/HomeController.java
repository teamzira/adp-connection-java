/*
	---------------------------------------------------------------------------
	Copyright © 2015-2016 ADP, LLC.   
	
	Licensed under the Apache License, Version 2.0 (the “License”); 
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at
	
	http://www.apache.org/licenses/LICENSE-2.0
	
	Unless required by applicable law or agreed to in writing, software 
	distributed under the License is distributed on an “AS IS” BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
	implied.  See the License for the specific language governing 
	permissions and limitations under the License.
	---------------------------------------------------------------------------
*/
package com.adp.marketplace.demo.client.auth.authcode;

import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.adp.marketplace.connection.configuration.AuthorizationCodeConfiguration;
import com.adp.marketplace.connection.core.ADPAPIConnectionFactory;
import com.adp.marketplace.connection.core.AuthorizationCodeConnection;
import com.adp.marketplace.connection.exception.ConnectionException;
import com.adp.marketplace.connection.vo.Token;
import com.adp.marketplace.demo.client.auth.authcode.utils.ClientUtils;


/**
 * 
 * HomeController is class that provides an example of usage of ADPConnection and 
 * ADPUserInfo Libraries for OAuth - Authorization Code.
 * 
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 * 
     * @param request HttpServletRequest
	 * @param locale Locale
	 * @param model  Model
	 * @return String  returns to home page
	 * 
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpServletRequest request, Locale locale, Model model) {
		
		logger.info("Welcome home! The client locale is {}.", locale);
		
		String formattedDate = null;
		
		formattedDate = getFormattedDate(locale);
		model.addAttribute("serverTime", formattedDate );
	
		return "home";
	}
	
	/**
	 *  <p>
	 *  This call initializes the AuthorizationCodeConfiguration object by 
	 *  reading properties and mapping to the configuration object. Once the 
	 *  Configuration Object is populated, a AuthorizationCodeConnection is 
	 *  obtained using ADPConnection library. Once the connection is 
	 *  established, authroization Url is obtained from connection and 
	 *  redirected to this acquired authroization Url.
	 * 
     * @param request HttpServletRequest
	 * @param locale Locale
	 * @param model  Model
	 * @return String  returns to home page
	 */
	@RequestMapping(value = "/authorizationCode", method = RequestMethod.GET)
	public String authorizationCode(HttpServletRequest request, Locale locale, Model model) {
		
		logger.info("Welcome home! The client locale is {}.", locale);
		
		String formattedDate = null;
		String authorizationUrl = "home";
		
		ClientUtils CLIENT_UTILS_INSTANCE = 
				com.adp.marketplace.demo.client.auth.authcode.utils.ClientUtils.getInstance();
		ADPAPIConnectionFactory CONNECTION_FACTORY_INSTANCE = 
				(ADPAPIConnectionFactory) ADPAPIConnectionFactory.getInstance();
		
		formattedDate = getFormattedDate(locale);
		model.addAttribute("serverTime", formattedDate );
		
		HttpSession httpSession = request.getSession();
		AuthorizationCodeConnection authorizationCodeConnection = 
				(AuthorizationCodeConnection) httpSession.getAttribute("AuthorizationCodeConnection");
		
		try { 
			
			if ( authorizationCodeConnection ==  null ) {
	
				//create authorization code configuration object
				AuthorizationCodeConfiguration authorizationCodeConfiguration = new AuthorizationCodeConfiguration();
				
				//get authorization code configuration properties 
				Properties properties = CLIENT_UTILS_INSTANCE.getConfigProperties();

				//populate authorization code configuration 
				CLIENT_UTILS_INSTANCE.mapPropertiesToAuthCodeConfiguration(properties, authorizationCodeConfiguration);
				
				//get ADP connection using Connection factory and configuration 
				authorizationCodeConnection = (AuthorizationCodeConnection)
						CONNECTION_FACTORY_INSTANCE.createConnection(authorizationCodeConfiguration); 			
			}
			
			httpSession.setAttribute("AuthorizationCodeConnection", authorizationCodeConnection);
			
			//get Url from authorization connection
			authorizationUrl = "redirect:" + authorizationCodeConnection.getAuthorizationUrl();
			
			System.out.println(" AUTHORIZATION URL: "+ authorizationUrl);
			
		} catch (ConnectionException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		return authorizationUrl;
	}
	
	/**
	 * A handler to process the ADP authorization server response that has 
	 * <b>code</b> value which is mapped in connection object to initiate 
	 * connect call for acquiring access token. If the access token is 
	 * acquired successfully the connection is populated with {@link Token} 
	 * information, if not, error response is populated in the 
	 * {@link AuthorizationCodeConnection}
	 * 
	 * @param request HttpServletRequest
	 * @param locale Locale
	 * @param model  Model
	 * @return String  returns to home page
	 */
	@RequestMapping(value = "/callback", method = RequestMethod.GET)
	public String callback(HttpServletRequest request, Locale locale, Model model) {
		
		logger.info("Welcome home! The client locale is {}.", locale);

		String errorMessage = null;
		String formattedDate = null;
		
		formattedDate = getFormattedDate(locale);
		
		model.addAttribute("serverTime", formattedDate );
		
		HttpSession httpSession = request.getSession();
		AuthorizationCodeConnection authorizationCodeConnection =
				(AuthorizationCodeConnection) httpSession.getAttribute("AuthorizationCodeConnection");
		
		if ( authorizationCodeConnection ==  null ) {
		
			// display error as connection is not present
			errorMessage =  "Callback - AuthorizationCodeConnection is Null - Connection is currently not availabe!!";
		
		} else {
			
			String callBackRequestError = (String) request.getParameter("error");
			System.out.println(" Callback - Request Error: " + callBackRequestError);
			
			if ( StringUtils.isBlank(callBackRequestError) ) {
				
				//get code value 
				String requestCode = (String) request.getParameter("code");
				System.out.println(" Callback - RequestCode: " + requestCode);
				
				if ( StringUtils.isNotBlank(requestCode) ) {
					
					//map request code to connection configuration
					((AuthorizationCodeConfiguration)authorizationCodeConnection.
							getConnectionConfiguration()).setAuthorizationCode(requestCode);
					
					try {
						
						AuthorizationCodeConfiguration config = ((AuthorizationCodeConfiguration) 
								authorizationCodeConnection.getConnectionConfiguration());
						System.out.println(" Callback - Config Mapped with Code: "+ config.getAuthorizationCode() );
						
						// call to ADPConnection Library
						authorizationCodeConnection.connect();
						
						// at this time this connection must have token info
						Token token = authorizationCodeConnection.getToken();
						
						if ( token != null) {
							
							System.out.println(" Callback - Token Info: " + token.toString());								
							com.adp.marketplace.demo.client.auth.authcode.pojo.Token responseToken = 
									new com.adp.marketplace.demo.client.auth.authcode.pojo.Token();
							
							responseToken.setAccessToken(token.getAccess_token());
							responseToken.setExpiresIn(token.getExpires_in());
							responseToken.setScope(token.getScope());
							responseToken.setIdToken(token.getId_token());
							responseToken.setRefreshToken(token.getRefresh_token());
							responseToken.setTokenType(token.getToken_type());
							
							httpSession.setAttribute("Token", responseToken);
							
						} else {
							errorMessage =  authorizationCodeConnection.getErrorResponse();
							System.out.println(" Error on Token Request - Message: " + errorMessage);
						}
						
					} catch (ConnectionException e) {
						errorMessage = "Callback - Connection Exception!";
					}
				} else {
					errorMessage =  "Callback - Code is Null - User Unauthorized!";
				}
				
			} else {
				errorMessage = "Callback - Connection is currently Unavailabe!";
			}
		}
		
		httpSession.setAttribute("AuthorizationCodeConnection", authorizationCodeConnection);
		httpSession.setAttribute("ErrorMessage", errorMessage);
		
		return "home";
	}	

	/**
	 * This method is called when Get Access token is clicked, and redirects to /authorizationCode 
	 * and instantiates a connection if called for the first time or uses existing
	 * connection
	 * 
	 * @param request HttpServletRequest
	 * @param locale Locale
	 * @param model  Model
	 * @return String  returns to home page
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(HttpServletRequest request, Locale locale, Model model) {
		
		logger.info("Welcome home! The client locale is {}.", locale);
		
		String formattedDate = null;
		
		formattedDate = getFormattedDate(locale);
		model.addAttribute("serverTime", formattedDate );
		
		HttpSession httpSession = request.getSession();
		AuthorizationCodeConnection authorizationCodeConnection = 
				(AuthorizationCodeConnection) httpSession.getAttribute("AuthorizationCodeConnection");
		
		if ( authorizationCodeConnection ==  null ) {
			//redirect to method authorizationCode
			return "redirect:authorizationCode";
		}
	
		return "home";
	}
	
	/**
	 * This method resets the existing connection in the session
	 * 
	 * @param request HttpServletRequest
	 * @param locale Locale
	 * @param model  Model
	 * @return String  returns to home page
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, Locale locale, Model model) {
		
		logger.info("Welcome home! The client locale is {}.", locale);
		
		String errorMessage = null;
		String formattedDate = null;
		
		formattedDate = getFormattedDate(locale);
		model.addAttribute("serverTime", formattedDate );
		
		HttpSession httpSession = request.getSession();
		AuthorizationCodeConnection authorizationCodeConnection = (AuthorizationCodeConnection) 
				httpSession.getAttribute("AuthorizationCodeConnection");
		
		if ( authorizationCodeConnection != null ) {
			
			try {		
				//resets AuthorizationCodeConnection to null
				authorizationCodeConnection.disconnect();
				
				//reset				
				httpSession.setAttribute("AuthorizationCodeConnection", null);
				httpSession.setAttribute("ErrorMessage", null);
				httpSession.setAttribute("Token", null);
				httpSession.setAttribute("UserInfo", null);
				
				
			} catch ( ConnectionException e ) {
				errorMessage = "/logout - Disconnect Error!";
			}
		}
		 			
		httpSession.setAttribute("ErrorMessage", errorMessage);
		
		return "home";
	}
	
	/**
	 *  Returns a string with server date and time 
	 *  
	 * @param locale 	@see Locale
	 * @return String  	returns server time when the request was made
	 */
	private String getFormattedDate(Locale locale) {
		
		String formattedDate = null;
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		formattedDate = dateFormat.format(date);
		
		return formattedDate;
	}
}
