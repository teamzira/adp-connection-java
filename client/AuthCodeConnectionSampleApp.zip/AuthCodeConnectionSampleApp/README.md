
# AuthCodeConnectionSampleApp - is a sample Web Application using ADPConnection Library
The ADPAuthCodeConnection Sample Application uses ADPConnection Library to simplify process of authentication, authorization and connecting to ADP Marketplace gateway.

## Installation

Unzip ADPAuthCodeConnection sample application and copy to {Home}/workspace/ so that it can be run as web application

Import the Sample Apps to your Eclipse IDE 

Do a one time setup for client certificates if not already done.

NOTE: 
certificates bundled in libraries will only work for ADP Sandbox environment

Refer ONE-TIME_CERTS_SETUP.md for jks key generation and cacerts update

Verify and(or) Update each clientConfig.properties for AuthCodeConnectionSampleApp:
 	
sslCertPath  - absolute path to the provided 'keystore.jks' or your own generated xxxxx.jks file

storePassword - if not using default password (adpadp10) this has to be updated based on what was used during creating keystore and truststore 

keyPassword - if not using default password (adpadp10) this has to be updated based on what was used during creating keystore and truststore
 		               
NOTE: for sslCertPath choose the appropriate path structure based on Windows/Unix/Linux

For running the web app: AuthCodeConnectionSampleApp
     
## Build the sample app

Execute below commands in command line from the AuthCodeConnectionSampleApp directory 
     
$mvn clean install -e
     
ECLIPSE:     

Assuming your eclipse is already configured to use maven:

Right click on pom.xml -> 

click Run As -> 

Run Configurations -> to create a new configuration 
     
## Maven Configuration Setup
Provide below details for new configuration tabs:
     
Main Tab

Name: Name of the Sample App 

Goals: clean install -e

Check relevant Check boxes: Update Snapshots, Debug Output 

JRE Tab: use default or use appropriate option

Refresh Tab: check Refresh

Common Tab: Check Debug and Run for 'Display in favorite menu'
    
Click Apply and Run 

Executing the command line or using Eclipse to run pom.xml would generate a 

marketplace-{version}.war file in the target folder if build was successful.


## Tomcat (other) Server Configuration
Configure your Server (Tomcat, JBoss, or any other) such that this web application would run on PORT: 8889 when the war is deployed on the server instead of default port 8080 

Ex: Tomcat Server: Using server admin console or editing directly in /apache-tomcat-8.0.24/conf/server.xml

<Connector executor="tomcatThreadPool" port="8889" protocol="HTTP/1.1" connectionTimeout="20000" redirectPort="8443" />

NOTE: Port 8889 should be available

## Deploy
Deploy AuthCodeConnectionSampleApp to Tomcat server

Note: 
if AuthCodeUserInfoSampleApp deployed on Tomcat Server please undeploy - as both the sample apps run at same  Host:Port/web context root/ - localhost:8889/marketplace/

Start Server 

Open a browser and access the home page using below url

http://localhost:8889/marketplace/

## Usage

**Steps to initialize connection**

Initialize Authorization Code Configuration based on Grant type **authorization_code**

Create AuthorizationCodeConnection Connection with initialized configuration

Invoke connect() on Connection to get Access Token from authorizationCodeConnection

Invoke getAccessToken() on Connection to obtain Access Token 

Invoke getErrorResponse() on Connection to obtain error details in case of no Access Token

** Create Authorization Code Connection**

	// create authorization code configuration object
	AuthorizationCodeConfiguration authorizationCodeConfiguration = new AuthorizationCodeConfiguration();
				
	// get authorization code configuration properties 
	Properties properties = com.adp.marketplace.demo.client.auth.authcode.utils.ClientUtils.getInstance().getConfigProperties();

	// populate authorization code configuration 
	com.adp.marketplace.demo.client.auth.authcode.utils.ClientUtils.getInstance()
		.mapPropertiesToAuthCodeConfiguration(properties,  authorizationCodeConfiguration);
				
	// get ADP connection using configuration above
	authorizationCodeConnection = (AuthorizationCodeConnection) ADPAPIConnectionFactory.getInstance().
		createConnection(authorizationCodeConfiguration); 			
		
	// get Url from authorization connection
	authorizationUrl = "redirect:" + authorizationCodeConnection.getAuthorizationUrl();

	// callback snippets
	String requestCode = (String) request.getParameter("code");
	String callBackRequestError = (String) request.getParameter("error");
	
	AuthorizationCodeConfiguration config = ((AuthorizationCodeConfiguration) 
	authorizationCodeConnection.getConnectionConfiguration());

	// call to ADPConnection Library
	authorizationCodeConnection.connect();
					
	// at this time this connection must have token info
	Token token = authorizationCodeConnection.getToken();

	// alternate flow - no token in connection 
	errorMessage = authorizationCodeConnection.getErrorResponse();

```
## Test AuthCodeConnectionSampleApp:

Once the page loads
    
Click 'Get Access Token'

Redirects to Login Page 

Provide User Id and Password 

UserId = MKPLDEMO

Password = marketplace1

Re-loads page with either Access Token Information or error details

Click Logout to clear current session

## API Documentation
Documentation on the individual API calls

Library Documentation

file://{HOME}/workspace/ADPConnection/doc/index.html

file://{HOME}/workspace/ADPUserInfo/doc/index.html

Sample App Documentation

file:///Users/tallaprs/Documents/Mars/workspace/AuthCodeConnectionSampleApp/doc/index.html

Additional documentation can also be found on the [ADP Developer Portal](https://developers.adp.com).

## Dependencies
This Sample application depends on the following libraries.

1.  commons-logging-1.2.jar
2.  commons-lang3-3.4.jar
3.  httpclient-4.5.1.jar
4.  httpcore-4.4.3.jar
5.  commons-codec-1.9.jar
6.  httpcore-osgi-4.4.4.jar
7.  httpcore-nio-4.4.4.jar
8.  gson-2.3.1.jar
9.  json-simple-1.1.1.jar
10. junit-4.12.jar
11. hamcrest-core-1.3.jar
12. slf4j-api-1.7.14.jar
13. ADPConnection-1.0.0.jar
14. spring-context-3.1.1.RELEASE.jar
15. spring-aop-3.1.1.RELEASE.jar
16. aopalliance-1.0.jar
17. spring-beans-3.1.1.RELEASE.jar
18. spring-core-3.1.1.RELEASE.jar
19. spring-expression-3.1.1.RELEASE.jar
20. spring-asm-3.1.1.RELEASE.jar
21. spring-webmvc-3.1.1.RELEASE.jar
22. spring-context-support-3.1.1.RELEASE.jar
23. spring-web-3.1.1.RELEASE.jar
24. aspectjrt-1.6.10.jar
25. jcl-over-slf4j-1.6.6.jar
26. log4j-1.2.15jar
27. javax.inject-1.jar
28. servlet-api-2.5.jar
29. jsp-api-2.1.jar
30. jstl-1.2.jar
31. junit-4.7.jar


## License
[Apache 2](http://www.apache.org/licenses/LICENSE-2.0)
